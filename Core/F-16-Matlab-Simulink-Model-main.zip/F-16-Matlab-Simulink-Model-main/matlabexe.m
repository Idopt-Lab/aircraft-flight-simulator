clc
clear all
%% Initial and Inertial values
% altitude= 400 m 
m   = 9298.5 ;  % kg
Ix  = 12875;   % kgm^2
Iy  = 75674;   % kgm^2
Iz  = 85552;   % kgm^2
Ixz = 1331;    % kgm^2
alpha=0;  % AoA (deg) optimum
U_0      = 205.8;    % m/s 
W_0      =5;         % m/s
zeic     = -7620 ;      % alttitude (meters), down positive
Paic     = 50;     % thrust percent
rho=    1.18; %kg/m^3
S=27.87; % area, m^2
b=9.144; % span, m
c_bar=3.45; % mean aerodynamic chord, m
%% Longitudinal and Lateral-directional derivatives
X_u	=   -0.005389;
Z_u=	-0.4221;
X_w=	0.03682;
Z_w	=   -1.561;
M_w =	0.01751;
M_wdot=	-0.00585558;

M_q	=   -1.789668;
Z_alpha	=-117.6154;
M_alpha=	4.4491658;
M_alpha_dot=	-1.48755859;
Y_beta=	-77.5736767899;
N_beta=	27.323822;
L_beta=	-140.1265;
N_p	=-0.0428495;
L_p	=-5.88436;
N_r	=-0.81006;
L_r=	1.1931423;
Y_del_a	=-1.802263;
N_del_a	=-7.14274;
L_del_a	=239.571;
Y_del_r	=22.929866;
N_del_r	=-9.523656;
L_del_r=	48.21557;
X_delta_e	=11.408;
Z_delta_e	=-117.6154;
X_delta_th	=-0.022453;
Z_delta_th=	-0.354755;
M_delta_e	=-62.90535;
M_delta_th=	0;
Y_p=1.208;
Y_r=1.6705;
g=0.81;
theta0=0;
M_u=0.02623;
T_r_roll= -1/L_p; %sec
T_r_yaw=-1/N_r; %sec
Y_phi = (L_beta * N_r) / Y_beta - L_r;
Cl_beta = -2 * L_beta / (rho * U_0^2 * S * b);
L_phi = - (1/2) * rho * U_0^2 * S * b * Cl_beta;

%% longitudinal channel transfer function
s=tf('s');
pitch_tf = ((-(M_delta_e+(M_alpha_dot*Z_delta_e/U_0))*s)-(M_alpha*Z_delta_e/(U_0-M_alpha*Z_alpha/U_0)))/((s*(s^2-(M_q+M_alpha_dot+(Z_alpha/U_0)*s+((Z_alpha*M_alpha/U_0)-M_alpha)))));

num = [62.11  2.351]; 
den = [1 0.534  10.1 0]; 
G = tf(num, den);
[A,B,C,D] = ssdata(G);
% longitudinal channel LQR controller
Q=5000*eye(3);
R=1;
K=lqr(A,B,Q,R);
N_bar=K(3);

%% lateral-directional channel ss matrix
A_lat = [Y_beta/U_0, Y_p/U_0, -(1-( Y_r/U_0)), (g/U_0)*cos(theta0), (g/U_0)*sin(theta0); 
         L_beta , L_p , L_r, 0,0;
         N_beta, N_p, N_r, 0,0;
         0, 1, 0, 0,0;
         0,0,0,1,0];
B_lat = [Y_del_a, Y_del_r/U_0;
         L_del_a , L_del_r;
         N_del_a, N_del_r;
         0,0;
         0,0];
C_lat=eye(5);
D_lat=[0,0;0,0;0,0;0,0;0,0];
sys=ss(A_lat, B_lat, C_lat, D_lat);
eig(A_lat);
% lateral-directional channel LQR controller
Q_lat=5000*eye(5);
R_lat=0.825;
[K_lat, S_lat, E_lat]= lqr(A_lat, B_lat, Q_lat, R_lat);
N_bar_lat=K_lat(3);
% İhtiyaç durumunda BURAYA TRACKING KODU EKLENEBİLİR
