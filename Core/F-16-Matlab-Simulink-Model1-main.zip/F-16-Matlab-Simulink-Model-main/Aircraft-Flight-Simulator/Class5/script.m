clear; clc;
f16 = Aircraft();
weight_N = 91188;
mass_kg = weight_N / 9.81;
Ixx = 12875; Iyy = 75674; Izz = 85552; Ixz = 1331; Iyz = 0;
cg = [0, 0, 0];
f16.mass.set_mass_properties(mass_kg, Ixx, Iyy, Izz, Ixz, Iyz, cg);
S = 27.87; b = 9.144; c = 3.45;
f16.geometry.add_component('wing','main_wing', S, b, c, true);
aileron = ControlSurface('aileron');
aileron.set_properties('aileron', [0.318 0 -0.063], deg2rad(20), deg2rad(-20), [1 0 0], 'aileron');
f16.add_control_surface(aileron);

elevator = ControlSurface('elevator');
elevator.set_properties('elevator', [0 -1.315 0], deg2rad(25), deg2rad(-25), [0 1 0], 'elevator');
f16.add_control_surface(elevator);

rudder = ControlSurface('rudder');
rudder.set_properties('rudder', [0.064 0 -0.084], deg2rad(30), deg2rad(-30), [0 0 1], 'rudder');
f16.add_control_surface(rudder);
f100 = PropulsiveElement('engine');
f100.set_properties('F100-PW-200', 20728, [-1.8 0 0], [1 0 0], 0.5);
f16.add_propulsive_element(f100);
lookup = F16Lookup();
f16.aero.set_lookup(lookup);
alt_m = 8967;
M = 0.60;
alpha_deg = 5.0;

[T, a, P, rho] = atmosisa(alt_m);
V = M * a;
alpha = deg2rad(alpha_deg);
x = zeros(12,1);
x(1) = 0; x(2) = 0; x(3) = -alt_m;
x(4) = V*cos(alpha); x(5) = 0; x(6) = V*sin(alpha);
x(7) = 0; x(8) = alpha; x(9) = 0;
x(10) = 0; x(11) = 0; x(12) = 0;
f16.state.set_full_state(x);

f16.set_control_by_name('aileron', deg2rad(0.0));
f16.set_control_by_name('elevator', deg2rad(-0.542247));
f16.set_control_by_name('rudder', deg2rad(0.0));
f16.set_control_by_name('F100-PW-200', 0.431670);

u = f16.control.get_full_controls();
[F_aero, M_aero] = f16.aero.calculate_forces_moments(x, u, f16.geometry, f16.control_surfaces);
[F_thrust, M_thrust] = f16.propulsive_forces();
[F_weight, M_weight] = f16.weight_force('constant');
F_total = F_aero + F_thrust + F_weight;
M_total = M_aero + M_thrust + M_weight;