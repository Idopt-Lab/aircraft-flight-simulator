clear; clc; close all;

f16 = Aircraft();
weight_N = 91188;
mass_kg = weight_N / 9.81;
Ixx = 12875; Iyy = 75674; Izz = 85552; Ixz = 1331; Iyz = 0;Ixy=0;
cg = [0, 0, 0];
f16.mass.set_mass_properties(mass_kg, Ixx, Iyy, Izz,Ixy, Ixz, Iyz, cg);
S = 27.87; b = 9.144; c = 3.45;
f16.geometry.add_component('wing','main_wing', S, b, c, true);
aileron = ControlSurface('aileron');
aileron.set_properties('aileron', [0.318 0 -0.063], deg2rad(20), deg2rad(-20), [1 0 0], 'aileron');
f16.add_control_surface(aileron);
elevator = ControlSurface('elevator');
elevator.set_properties('elevator', [0 -1.315 0], deg2rad(25), deg2rad(-25), [0 1 0], 'elevator');
f16.add_control_surface(elevator);
rudder = ControlSurface('rudder');
rudder.set_properties('rudder', [0.064 0 -0.084], deg2rad(30), deg2rad(-30), [0 0 1], 'rudder');
f16.add_control_surface(rudder);
f100 = PropulsiveElement('engine');
f100.set_properties('F100-PW-200', 20728, [-1.8 0 0], [1 0 0], 0.5);
f16.add_propulsive_element(f100);
lookup = F16Lookup();
f16.aero.set_lookup(lookup);

% Flight plan
flight_plan = struct();
flight_plan.waypoints = [
    0,    1000,  200, 0.8;
    300,  8967,  220, 0.75;
    900,  8967,  220, 0.6;
    1200, 1000,  180, 0.4;
];

% Simulation parameters
dt = 0.1;
total_time = 1200;
time_steps = 0:dt:total_time;
n_steps = length(time_steps);

% Initialize data storage
flight_data = struct();
flight_data.time = time_steps;
flight_data.altitude = zeros(1, n_steps);
flight_data.airspeed = zeros(1, n_steps);
flight_data.controls = zeros(4, n_steps);
flight_data.forces = zeros(3, n_steps);
flight_data.moments = zeros(3, n_steps);
Initialpos = [0,0,-1000];
InitialVel = [180,0,3.14];
InitialOri = [0,0.0175,0];
InitialRot = [0,0,0];
Inertia = f16.mass.get_inertia_matrix();
for i = 1:n_steps
    t = time_steps(i);
    target_alt = interp1(flight_plan.waypoints(:,1), flight_plan.waypoints(:,2), t, 'linear', 'extrap');
    target_speed = interp1(flight_plan.waypoints(:,1), flight_plan.waypoints(:,3), t, 'linear', 'extrap');
    target_throttle = interp1(flight_plan.waypoints(:,1), flight_plan.waypoints(:,4), t, 'linear', 'extrap');
    if t <= 300
        alpha = deg2rad(10.0);
        elevator_trim = deg2rad(-3.0);
    elseif t <= 900
        alpha = deg2rad(5.0);
        elevator_trim = deg2rad(-1.0);
    else
        alpha = deg2rad(1.0);
        elevator_trim = deg2rad(0.5);
    end

    x = zeros(12,1);
    x(1) = target_speed * t * cos(alpha);  
    x(2) = 0;                              
    x(3) = -target_alt;                    
    x(4) = target_speed * cos(alpha);      
    x(5) = 0;                              
    x(6) = target_speed * sin(alpha);      
    x(7) = 0;                              
    x(8) = alpha;                          
    x(9) = 0;                              
    x(10:12) = 0;                          
    f16.state.set_full_state(x);
    f16.set_control_by_name('aileron', deg2rad(0.0));
    f16.set_control_by_name('elevator', elevator_trim);
    f16.set_control_by_name('rudder', deg2rad(0.0));
    f16.set_control_by_name('F100-PW-200', target_throttle);
    state = f16.state.get_full_state();
    controls = f16.control.get_full_controls();
   
    [F_aero, M_aero] = f16.aero.calculate_forces_moments(state, controls, f16.geometry, f16.control_surfaces);
    [F_prop, M_prop] = PropulsiveElement.calculate_total_forces(f16.propulsive_elements, state, controls);
    [F_weight, M_weight] = f16.mass.calculate_weight_forces(state, 'constant');
    
    F_total = F_aero + F_prop + F_weight;
    M_total = M_aero + M_prop + M_weight;
    flight_data.altitude(i) = target_alt;
    flight_data.airspeed(i) = target_speed;
    flight_data.controls(:, i) = controls;  % Fixed: use controls instead of undefined 'u'
    flight_data.forces(:, i) = F_total;
    flight_data.moments(:, i) = M_total;
    run('Flightsim')
end
state = f16.state.get_full_state();

assignin('base', 'aircraft_obj', f16);
assignin('base', 'initial_state', state);
fprintf('Aircraft object loaded into workspace for Simulink interface\n');
fprintf('Initial Position: [%.2f, %.2f, %.2f] m\n', Initialpos);
fprintf('Initial Velocity: [%.2f, %.2f, %.2f] m/s\n', InitialVel);
fprintf('Initial Orientation: [%.4f, %.4f, %.4f] rad\n', InitialOri);
figure('Position', [100, 100, 1400, 800]);

subplot(2,3,1);
plot(flight_data.time, flight_data.altitude, 'b-', 'LineWidth', 2);
grid on; xlabel('Time (s)'); ylabel('Altitude (m)'); title('Flight Profile');

subplot(2,3,2);
plot(flight_data.time, flight_data.airspeed, 'g-', 'LineWidth', 2);
grid on; xlabel('Time (s)'); ylabel('Airspeed (m/s)'); title('Airspeed Profile');

subplot(2,3,3);
plot(flight_data.time, flight_data.controls(4,:)*100, 'b-', 'LineWidth', 2);
grid on; xlabel('Time (s)'); ylabel('Throttle (%)'); title('Throttle Setting');

subplot(2,3,4);
plot(flight_data.time, flight_data.forces(1,:)/1000, 'r-', 'LineWidth', 1.5); hold on;
plot(flight_data.time, flight_data.forces(3,:)/1000, 'b-', 'LineWidth', 1.5);
grid on; xlabel('Time (s)'); ylabel('Force (kN)'); title('Forces'); legend('Fx', 'Fz');

subplot(2,3,5);
plot(flight_data.time, flight_data.moments(2,:)/1000, 'g-', 'LineWidth', 2);
grid on; xlabel('Time (s)'); ylabel('Moment (kN⋅m)'); title('Pitching Moment');

subplot(2,3,6);
x_pos = flight_data.airspeed .* flight_data.time * cos(deg2rad(5)) / 1000;
plot3(x_pos, zeros(size(x_pos)), flight_data.altitude/1000, 'b-', 'LineWidth', 2);
grid on; xlabel('X (km)'); ylabel('Y (km)'); zlabel('Altitude (km)'); title('3D Trajectory'); view(45, 30);
