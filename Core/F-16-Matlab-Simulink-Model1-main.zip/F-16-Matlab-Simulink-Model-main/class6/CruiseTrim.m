clear; clc;

f16 = Aircraft();

weight_N = 91188;
mass_kg = weight_N / 9.81;
Ixx = 12875; Iyy = 75674; Izz = 85552; Ixz = 1331; Iyz = 0; Ixy = 0;
cg = [0, 0, 0];
f16.mass.set_mass_properties(mass_kg, Ixx, Iyy, Izz, Ixy, Ixz, Iyz, cg);
S = 27.87; b = 9.144; c = 3.45;
f16.geometry.add_component('wing', 'main_wing', S, b, c, true, [0, 0, 0]);

aileron = ControlSurface('aileron');
aileron.set_properties('aileron', [0.318 0 -0.063], deg2rad(20), deg2rad(-20), [1 0 0], 'aileron');
f16.add_control_surface(aileron);

elevator = ControlSurface('elevator');
elevator.set_properties('elevator', [0 -1.315 0], deg2rad(25), deg2rad(-25), [0 1 0], 'elevator');
f16.add_control_surface(elevator);

rudder = ControlSurface('rudder');
rudder.set_properties('rudder', [0.064 0 -0.084], deg2rad(30), deg2rad(-30), [0 0 1], 'rudder');
f16.add_control_surface(rudder);

f100 = PropulsiveElement('engine');
f100.set_properties('F100_PW_200', 25000*4.448, [-1.8 0 0], [1 0 0], 0.477); % 25,000 lb class = 111,200 N
f16.add_propulsive_element(f100);

lookup = F16Lookup();
f16.aero.set_lookup(lookup);
alpha_range = 0:0.1:12;
velocity_range = 10:2:550;
altitude = 8676;
mach = 0.6;

[T, a, P, rho] = atmosisa(altitude);
V_fixed = mach * a;
q_bar_fixed = 0.5 * rho * V_fixed^2;

results_alpha = struct();
results_alpha.alpha_deg = alpha_range;
results_alpha.L_D_ratio = zeros(size(alpha_range));
results_alpha.Tr_Vinf = zeros(size(alpha_range));
results_alpha.Pr_Vinf = zeros(size(alpha_range));

for i = 1:length(alpha_range)
    alpha_deg = alpha_range(i);
    alpha_rad = deg2rad(alpha_deg);
    
    x = zeros(12,1);
    x(1) = 0; x(2) = 0; x(3) = -altitude;
    x(4) = V_fixed*cos(alpha_rad); x(5) = 0; x(6) = V_fixed*sin(alpha_rad);
    x(7) = 0; x(8) = alpha_rad; x(9) = 0;
    x(10) = 0; x(11) = 0; x(12) = 0;
    f16.state.set_full_state(x);
    f16.set_control_by_name('aileron', deg2rad(0.0));
    f16.set_control_by_name('elevator', deg2rad(0.6575));
    f16.set_control_by_name('rudder', deg2rad(0.0));
    f16.set_control_by_name('F100_PW_200', 0.3223);
    
    state = f16.state.get_full_state();
    controls = f16.control.get_full_controls();
    coeffs = lookup(state, controls, f16.geometry);
    
    % Ensure positive coefficients
    CL = max(coeffs.CL, 0.001);
    CD = max(coeffs.CD, 0.001);
    
    lift = q_bar_fixed * S * CL;
    drag = q_bar_fixed * S * CD;
    
    L_D = lift / drag;
    thrust_required = drag;
    power_required = thrust_required * V_fixed;
    Tr_Vinf = thrust_required / V_fixed;
    Pr_Vinf = power_required / V_fixed;
    
    results_alpha.L_D_ratio(i) = L_D;
    results_alpha.Tr_Vinf(i) = Tr_Vinf;
    results_alpha.Pr_Vinf(i) = Pr_Vinf;
end

alpha_trim = deg2rad(3.0);
results_velocity = struct();
results_velocity.velocity = velocity_range;
results_velocity.thrust_required = zeros(size(velocity_range));
results_velocity.thrust_available = zeros(size(velocity_range));
results_velocity.mach = zeros(size(velocity_range));

for i = 1:length(velocity_range)
    V = velocity_range(i);
    mach_current = V / a;
    q_bar = 0.5 * rho * V^2;
    
    x = zeros(12,1);
    x(1) = 0; x(2) = 0; x(3) = -altitude;
    x(4) = V*cos(alpha_trim); x(5) = 0; x(6) = V*sin(alpha_trim);
    x(7) = 0; x(8) = alpha_trim; x(9) = 0;
    x(10) = 0; x(11) = 0; x(12) = 0;
    f16.state.set_full_state(x);
    f16.set_control_by_name('aileron', deg2rad(0.0));
    f16.set_control_by_name('elevator', deg2rad(0.6575));
    f16.set_control_by_name('rudder', deg2rad(0.0));
    f16.set_control_by_name('F100_PW_200', 1.0);
    
    state = f16.state.get_full_state();
    controls = f16.control.get_full_controls();
    coeffs = lookup(state, controls, f16.geometry);
    
    drag = q_bar * S * max(coeffs.CD, 0.001);
    thrust_available = coeffs.thrust_available;
    
    results_velocity.thrust_required(i) = drag;
    results_velocity.thrust_available(i) = thrust_available;
    results_velocity.mach(i) = mach_current;
end
results_power = struct();
results_power.velocity = velocity_range;
results_power.power_required = zeros(size(velocity_range));
results_power.power_available = zeros(size(velocity_range));

for i = 1:length(velocity_range)
    V = velocity_range(i);
    results_power.power_required(i) = results_velocity.thrust_required(i) * V;
    results_power.power_available(i) = results_velocity.thrust_available(i) * V;
end
results_LD = struct();
results_LD.lift = zeros(size(alpha_range));
results_LD.drag = zeros(size(alpha_range));

for i = 1:length(alpha_range)
    alpha_deg = alpha_range(i);
    alpha_rad = deg2rad(alpha_deg);
    
    x = zeros(12,1);
    x(1) = 0; x(2) = 0; x(3) = -altitude;
    x(4) = V_fixed*cos(alpha_rad); x(5) = 0; x(6) = V_fixed*sin(alpha_rad);
    x(7) = 0; x(8) = alpha_rad; x(9) = 0;
    x(10) = 0; x(11) = 0; x(12) = 0;
    f16.state.set_full_state(x);
    
    f16.set_control_by_name('aileron', 0);
    f16.set_control_by_name('elevator', 0);
    f16.set_control_by_name('rudder', 0);
    f16.set_control_by_name('F100_PW_200', 0.7);
    
    state = f16.state.get_full_state();
    controls = f16.control.get_full_controls();
    coeffs = lookup(state, controls, f16.geometry);
    CL = max(coeffs.CL, 0.001);
    CD = max(coeffs.CD, 0.001);
    lift = q_bar_fixed * S * CL;
    drag = q_bar_fixed * S * CD;
    results_LD.lift(i) = lift/1000;
    results_LD.drag(i) = drag/1000;
end

figure('Position', [100, 100, 1200, 800]);

figure('Position', [100, 100, 1600, 1000]);

subplot(2,3,1);
plot(results_alpha.alpha_deg, results_alpha.L_D_ratio, 'b-', 'LineWidth', 2);
grid on;
xlabel('Angle of Attack (degrees)');
ylabel('L/D Ratio');
title('L/D vs Angle of Attack');
ylim([0, 15]);
subplot(2,3,2);
plot(results_alpha.alpha_deg, results_alpha.Tr_Vinf, 'r-', 'LineWidth', 2);
grid on;
xlabel('Angle of Attack (degrees)');
ylabel('Thrust Required / V∞ (N·s/m)');
title('Tr/V∞ vs Angle of Attack');
subplot(2,3,3);
plot(results_alpha.alpha_deg, results_alpha.Pr_Vinf/1000, 'g-', 'LineWidth', 2);
grid on;
xlabel('Angle of Attack (degrees)');
ylabel('Power Required / V∞ (kW·s/m)');
title('Pr/V∞ vs Angle of Attack');
subplot(2,3,4);
plot(results_LD.drag, results_LD.lift, 'k-', 'LineWidth', 2);
grid on;
xlabel('Drag (kN)');
ylabel('Lift (kN)');
title('Lift vs Drag');

subplot(2,3,5);
plot(results_velocity.velocity, results_velocity.thrust_required/1000, 'r-', 'LineWidth', 2);
hold on;
plot(results_velocity.velocity, results_velocity.thrust_available/1000, 'b-', 'LineWidth', 2);
grid on;
xlabel('Velocity (m/s)');
ylabel('Thrust (kN)');
title('Thrust Required vs Available');
legend('Thrust Required', 'Thrust Available', 'Location', 'best');

subplot(2,3,6);
plot(results_power.velocity, results_power.power_required/1000, 'r-', 'LineWidth', 2);
hold on;
plot(results_power.velocity, results_power.power_available/1000, 'b-', 'LineWidth', 2);
grid on;
xlabel('Velocity (m/s)');
ylabel('Power (kW)');
title('Power Required vs Available');
legend('Power Required', 'Power Available', 'Location', 'best');

intersection_idx = [];
for j = 1:length(results_velocity.velocity)-1
    if (results_velocity.thrust_available(j) - results_velocity.thrust_required(j)) * ...
       (results_velocity.thrust_available(j+1) - results_velocity.thrust_required(j+1)) < 0
        intersection_idx = j;
        break;
    end
end

[max_LD, idx_max] = max(results_alpha.L_D_ratio);

%% ADDITIONAL PERFORMANCE CALCULATIONS

% Fuel capacity
fuel_capacity_kg = 3200;
fuel_capacity_lbs = fuel_capacity_kg * 2.205;

%% 1. RATE OF CLIMB ANALYSIS
altitude_climb_range = 0:1000:15000;
climb_performance = struct();
climb_performance.altitude = altitude_climb_range;
climb_performance.rate_of_climb = zeros(size(altitude_climb_range));
climb_performance.optimal_velocity = zeros(size(altitude_climb_range));

for i = 1:length(altitude_climb_range)
    alt = altitude_climb_range(i);
    [T, a, P, rho] = atmosisa(alt);
    
    velocity_test = 100:10:400;
    max_climb_rate = 0;
    optimal_V = 200;
    
    for V = velocity_test
        alpha_trim = deg2rad(3.0);
        
        x = zeros(12,1);
        x(1) = 0; x(2) = 0; x(3) = -alt;
        x(4) = V*cos(alpha_trim); x(5) = 0; x(6) = V*sin(alpha_trim);
        x(7) = 0; x(8) = alpha_trim; x(9) = 0;
        x(10) = 0; x(11) = 0; x(12) = 0;
        f16.state.set_full_state(x);
        
        f16.set_control_by_name('aileron', 0);
        f16.set_control_by_name('elevator', 0);
        f16.set_control_by_name('rudder', 0);
        f16.set_control_by_name('F100_PW_200', 1.0);
        
        state = f16.state.get_full_state();
        controls = f16.control.get_full_controls();
        coeffs = lookup(state, controls, f16.geometry);
        
        q_bar = 0.5 * rho * V^2;
        drag = q_bar * S * max(coeffs.CD, 0.001);
        thrust_available = coeffs.thrust_available;
        
        excess_thrust = thrust_available - drag;
        if excess_thrust > 0
            rate_of_climb = (excess_thrust * V) / weight_N;
            if rate_of_climb > max_climb_rate
                max_climb_rate = rate_of_climb;
                optimal_V = V;
            end
        end
    end
    
    climb_performance.rate_of_climb(i) = max_climb_rate;
    climb_performance.optimal_velocity(i) = optimal_V;
end

%% 2. TIME TO CLIMB ANALYSIS
target_altitudes = [0, 3000, 6000, 9000, 12000, 15000];
time_to_climb = zeros(size(target_altitudes));

for i = 2:length(target_altitudes)
    h_start = target_altitudes(i-1);
    h_end = target_altitudes(i);
    
    h_points = linspace(h_start, h_end, 20);
    dt_sum = 0;
    
    for j = 1:length(h_points)-1
        h1 = h_points(j);
        h2 = h_points(j+1);
        
        rc1 = interp1(altitude_climb_range, climb_performance.rate_of_climb, h1, 'linear', 'extrap');
        rc2 = interp1(altitude_climb_range, climb_performance.rate_of_climb, h2, 'linear', 'extrap');
        
        if rc1 > 0.1 && rc2 > 0.1
            dt_sum = dt_sum + (h2-h1) * (1/rc1 + 1/rc2) / 2;
        end
    end
    
    time_to_climb(i) = time_to_climb(i-1) + dt_sum;
end

%% 3. ENDURANCE AND RANGE ANALYSIS
cruise_altitudes = [3000, 6000, 9000, 12000];
endurance_results = struct();
range_results = struct();

for i = 1:length(cruise_altitudes)
    alt = cruise_altitudes(i);
    [T, a, P, rho] = atmosisa(alt);
    
    mach_range_cruise = 0.4:0.1:0.9;
    endurance_data = [];
    range_data = [];
    
    for M = mach_range_cruise
        V = M * a;
        alpha_cruise = deg2rad(3.0);
        
        x = zeros(12,1);
        x(1) = 0; x(2) = 0; x(3) = -alt;
        x(4) = V*cos(alpha_cruise); x(5) = 0; x(6) = V*sin(alpha_cruise);
        x(7) = 0; x(8) = alpha_cruise; x(9) = 0;
        x(10) = 0; x(11) = 0; x(12) = 0;
        f16.state.set_full_state(x);
        
        f16.set_control_by_name('aileron', 0);
        f16.set_control_by_name('elevator', 0);
        f16.set_control_by_name('rudder', 0);
        f16.set_control_by_name('F100_PW_200', 0.6);
        
        state = f16.state.get_full_state();
        controls = f16.control.get_full_controls();
        coeffs = lookup(state, controls, f16.geometry);
        
        q_bar = 0.5 * rho * V^2;
        lift = q_bar * S * max(coeffs.CL, 0.001);
        drag = q_bar * S * max(coeffs.CD, 0.001);
        L_D_ratio = lift / drag;
        thrust_required = drag;
        
        sfc = 0.8 + 0.3 * (alt/10000);
        fuel_flow_lbs_hr = (thrust_required / 4.448) * sfc;
        
        if fuel_flow_lbs_hr > 0
            endurance_hours = fuel_capacity_lbs / fuel_flow_lbs_hr;
            range_km = (V * 3.6) * endurance_hours;
            
            endurance_data = [endurance_data; M, V, endurance_hours];
            range_data = [range_data; M, V, range_km, L_D_ratio];
        end
    end
    
    field_name = sprintf('alt_%dm', alt);
    endurance_results.(field_name) = endurance_data;
    range_results.(field_name) = range_data;
end

%% ADDITIONAL PLOTS
figure('Position', [100, 100, 1600, 1200]);

subplot(3,3,1);
plot(results_alpha.alpha_deg, results_alpha.L_D_ratio, 'b-', 'LineWidth', 2);
grid on; xlabel('Angle of Attack (degrees)'); ylabel('L/D Ratio'); title('L/D vs Angle of Attack'); ylim([0, 15]);

subplot(3,3,2);
plot(results_alpha.alpha_deg, results_alpha.Tr_Vinf, 'r-', 'LineWidth', 2);
grid on; xlabel('Angle of Attack (degrees)'); ylabel('Thrust Required / V∞ (N·s/m)'); title('Tr/V∞ vs Angle of Attack');

subplot(3,3,3);
plot(results_alpha.alpha_deg, results_alpha.Pr_Vinf/1000, 'g-', 'LineWidth', 2);
grid on; xlabel('Angle of Attack (degrees)'); ylabel('Power Required / V∞ (kW·s/m)'); title('Pr/V∞ vs Angle of Attack');

subplot(3,3,4);
plot(results_LD.drag, results_LD.lift, 'k-', 'LineWidth', 2);
grid on; xlabel('Drag (kN)'); ylabel('Lift (kN)'); title('Lift vs Drag');

subplot(3,3,5);
plot(results_velocity.velocity, results_velocity.thrust_required/1000, 'r-', 'LineWidth', 2);
hold on; plot(results_velocity.velocity, results_velocity.thrust_available/1000, 'b-', 'LineWidth', 2);
grid on; xlabel('Velocity (m/s)'); ylabel('Thrust (kN)'); title('Thrust Required vs Available');
legend('Thrust Required', 'Thrust Available', 'Location', 'best');

subplot(3,3,6);
plot(results_power.velocity, results_power.power_required/1000, 'r-', 'LineWidth', 2);
hold on; plot(results_power.velocity, results_power.power_available/1000, 'b-', 'LineWidth', 2);
grid on; xlabel('Velocity (m/s)'); ylabel('Power (kW)'); title('Power Required vs Available');
legend('Power Required', 'Power Available', 'Location', 'best');

subplot(3,3,7);
plot(altitude_climb_range/1000, climb_performance.rate_of_climb, 'b-', 'LineWidth', 2);
grid on; xlabel('Altitude (km)'); ylabel('Rate of Climb (m/s)'); title('Rate of Climb vs Altitude');

subplot(3,3,8);
plot(target_altitudes/1000, time_to_climb/60, 'r-o', 'LineWidth', 2, 'MarkerSize', 6);
grid on; xlabel('Altitude (km)'); ylabel('Time to Climb (minutes)'); title('Time to Climb');

subplot(3,3,9);
mach_test = 0.4:0.1:0.9;
endurance_9km = endurance_results.alt_9000m;
if ~isempty(endurance_9km)
    plot(endurance_9km(:,1), endurance_9km(:,3), 'g-o', 'LineWidth', 2);
    grid on; xlabel('Mach Number'); ylabel('Endurance (hours)'); title('Endurance at 9km');
end