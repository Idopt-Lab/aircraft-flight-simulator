classdef Atmosphere < handle
    properties
        model_type = 'ISA'  % 'ISA', 'custom', 'tabular'
        wind_model = []
        turbulence_model = []
        custom_data = struct()
    end
    
    methods
        function atm = Atmosphere(model_type)
            if nargin >= 1
                atm.model_type = model_type;
            end
        end
        
        function [rho, pressure, temperature, speed_of_sound] = get_conditions(atm, altitude)
            switch atm.model_type
                case 'ISA'
                    [temperature, speed_of_sound, pressure, rho] = atmosisa(altitude);
                case 'custom'
                    % User-defined atmospheric model
                    if isfield(atm.custom_data, 'rho_func')
                        rho = atm.custom_data.rho_func(altitude);
                    else
                        [temperature, speed_of_sound, pressure, rho] = atmosisa(altitude);
                    end
                    if isfield(atm.custom_data, 'pressure_func')
                        pressure = atm.custom_data.pressure_func(altitude);
                    end
                    if isfield(atm.custom_data, 'temperature_func')
                        temperature = atm.custom_data.temperature_func(altitude);
                        speed_of_sound = sqrt(1.4 * 287 * temperature);
                    end
                otherwise
                    [temperature, speed_of_sound, pressure, rho] = atmosisa(altitude);
            end
        end
        
        function wind_velocity = get_wind(atm, position, time)
            if isempty(atm.wind_model)
                wind_velocity = [0; 0; 0];
            else
                wind_velocity = atm.wind_model(position, time);
            end
        end
        
        function set_wind_model(atm, wind_function)
            atm.wind_model = wind_function;
        end
        
        function set_turbulence_model(atm, turbulence_function)
            atm.turbulence_model = turbulence_function;
        end
    end
end
